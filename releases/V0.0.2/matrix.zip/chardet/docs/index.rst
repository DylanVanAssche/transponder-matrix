chardet
=======

Character encoding auto-detection in Python. As smart as your browser.
Open source.

Documentation
=============

.. toctree::
   :maxdepth: 2

   faq
   supported-encodings
   usage
   how-it-works
   api/modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
