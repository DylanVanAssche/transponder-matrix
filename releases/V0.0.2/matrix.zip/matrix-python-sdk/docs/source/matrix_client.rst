matrix_client package
=====================

matrix_client.client
---------------------------

.. automodule:: matrix_client.client
    :members:
    :undoc-members:
    :show-inheritance:

matrix_client.api
------------------------

.. automodule:: matrix_client.api
    :members:
    :undoc-members:
    :show-inheritance:
